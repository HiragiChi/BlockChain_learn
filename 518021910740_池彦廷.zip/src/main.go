package main

import test "blockChain/Test"

func main() {
	test.Test(3,3)
	// test.Hello()
}
